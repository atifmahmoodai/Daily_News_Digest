// Offline mocked regression checks: node test_workflow.js
const fs=require('fs'),assert=require('assert');
const w=JSON.parse(fs.readFileSync(__dirname+'/Daily_News_Digest.json','utf8'));
const nodes=Object.fromEntries(w.nodes.map(n=>[n.name,n]));
for(const n of w.nodes)if(n.parameters.jsCode)new Function('$','$json',n.parameters.jsCode);
for(const [s,ports] of Object.entries(w.connections)){assert(nodes[s]);for(const list of Object.values(ports))for(const group of list)for(const e of group)assert(nodes[e.node]);}
assert(w.active===false);for(const n of w.nodes){assert(!n.credentials);assert(!n.onError);}
const cfg={maxArticles:40,lookbackDays:2,minScore:60,maxHeadlines:8,spreadsheetId:'demo'};
function normalize(items,seen=[]){return new Function('$',nodes['Normalize + Dedupe'].parameters.jsCode)(name=>({first:()=>({json:cfg}),all:()=>name==='Get Seen Articles'?seen.map(article_id=>({json:{article_id}})):items}));}
function article(url,topic='test'){return {json:{link:url,title:'A sufficiently long title for news',topicTag:topic,isoDate:new Date().toISOString()}};}
const urls=['https://example.com/'+ 'a'.repeat(310)+'1','https://example.com/'+ 'a'.repeat(310)+'2'];assert.equal(normalize(urls.map(u=>article(u))).length,2);
assert.equal(normalize([article(urls[0]),article(urls[0])]).length,1);assert.equal(normalize([article(urls[0])],[urls[0]]).length,0);
const samples=['n8n','AI','Voice','Freelance'].flatMap((t,k)=>Array.from({length:40},(_,i)=>article(`https://example.com/${k}/${i}`,t)));const balanced=normalize(samples);assert.equal(balanced.length,40);for(const topic of ['n8n','AI','Voice','Freelance'])assert.equal(balanced.filter(x=>x.json.topic===topic).length,10);
const old=article('https://example.com/old');old.json.isoDate='2000-01-01';assert.equal(normalize([old]).length,0);
function digest(items){return new Function('$',nodes['Build Digest Message'].parameters.jsCode)(()=>({first:()=>({json:cfg}),all:()=>items}))[0].json;}
const msg=digest(Array.from({length:8},()=>({json:{title:'A'.repeat(200),source:'S'.repeat(90),relevance:99}})));assert(msg.message.length<=1000);assert.equal(msg.count,msg.message.split('\n').length);assert.equal(digest([{json:{relevance:20}}]).count,0);
assert.equal(w.connections['Has Headlines'].main[1][0].node,'Articles to Commit');assert.equal(w.connections['Push Daily Headlines'].main[0][0].node,'Articles to Commit');assert.equal(w.connections['Articles to Commit'].main[0][0].node,'Save Article');assert.equal(nodes['Append to News Sheet'].parameters.operation,'appendOrUpdate');
const rate=new Function('$','$json',nodes['Attach Rating'].parameters.jsCode);const access=()=>({item:{json:{article_id:'test'}}});assert.throws(()=>rate(access,{text:'invalid'}));assert.throws(()=>rate(access,{text:{relevance:200}}));assert.equal(rate(access,{text:{relevance:90,is_relevant:true,summary:'Summary',why_it_matters:'Useful'}}).json.relevance,90);
console.log('PASS: syntax, graph, sanitization, full URLs, dedupe, topic balance, dates, digest limits/count, low-score branch, commit ordering, upserts and rating validation. Live n8n execution not tested.');
