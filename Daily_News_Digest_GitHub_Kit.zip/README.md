## Daily News Digest

Import Daily_News_Digest.json and follow Daily_News_Digest_Guide.pdf.

# Daily News Digest

An n8n workflow that finds recent automation news, scores its relevance, saves a searchable archive, and sends a short daily notification.

## What is included

<b>Daily_News_Digest.json</b>: the repaired, sanitized workflow.<br/><b>This guide</b>: setup, testing, alternatives, troubleshooting and release notes.<br/><b>README.md and test_workflow.js</b>: repository instructions and reproducible offline checks in the ZIP.

## How it works

At 8 AM, the workflow searches four Google News RSS feeds. It removes previously committed links, rejects undated or stale results, balances topics across up to 40 articles, and uses a Basic LLM Chain to score them. It writes all rated items to Google Sheets, sends up to eight qualifying headlines, then records completion in an n8n data table.

## Before you begin

You need an n8n installation with Data Table, RSS Read, Basic LLM Chain, Structured Output Parser, xAI Grok Chat Model, Google Sheets and Pushover nodes. Connect your own accounts. The downloadable template is free; hosting and service usage may cost money. No specific paid plan or free quota is assumed.

## Validation status

JSON, JavaScript and mocked logic tests are checked locally. Live import and execution in your n8n version, real model availability, credentials and external service delivery are <b>not verified</b>. Complete the first-run checks before recording or publishing claims that it works end to end.

Created for Atif Mahmood's tutorial audience. More tutorials: <link href="https://youtube.com/@atifmahmoodai" color="#087f8c">youtube.com/@atifmahmoodai</link>

# Create your table and sheet

## 1. Create the n8n data table

In n8n, open Data Tables and create <b>news_digest_seen</b>. Add the following custom columns. Copy the table ID, or select the same table in both Get Seen Articles and Save Article after importing.

Column | Type

article_id | String - complete article URL

title, url, source, topic | String (one column for each name)

published_at, seen_at | String - ISO timestamps

relevance | Number

summary, why_it_matters | String (one column for each name)

Do not shorten article_id. The old workflow truncated links; the replacement uses complete URLs. Start with a new table if old truncated IDs exist, accepting that a few previously seen stories may appear again.

## 2. Create the Google spreadsheet

Create a spreadsheet called <b>News-Digest-Tracker</b> with a tab named <b>News</b>. Put these exact headers in row 1, one header per column:

<b>article_id, date, topic, relevance, title, summary, why_it_matters, source, url, published_at</b>

Copy the spreadsheet ID from its URL: the portion between /d/ and /edit. In Append to News Sheet, use <b>Append or Update Row</b>, matching on <b>article_id</b>. Keep the supplied mappings. Use RAW cell formatting so incoming text is stored as text rather than interpreted as formulas.

## Why two storage locations?

The sheet is your readable news archive. The n8n table tracks completed processing. Sheet writes happen first; a failed notification does not commit the articles as seen. Sheet upserts reduce duplicate rows when retrying, provided runs do not overlap.

# Import and connect accounts

<b>1.</b> Create a new n8n workflow. Use Import from File and choose Daily_News_Digest.json. Keep it inactive while configuring.

<b>2.</b> Open Setup. Replace REPLACE_DATA_TABLE_ID and REPLACE_SPREADSHEET_ID. The tab defaults to News. These are resource identifiers, not API credentials.

<b>3.</b> Open News Model. Create/select your xAI credentials and replace SELECT_AVAILABLE_XAI_MODEL with a model available in your account. The placeholder intentionally prevents an accidental run with an assumed model name.

<b>4.</b> Open Append to News Sheet and connect Google Sheets credentials with access to your spreadsheet. Re-select the spreadsheet/tab if your n8n version requires it. Refresh columns if mappings show warnings; preserve article_id as the match column.

<b>5.</b> In Pushover, create an application and obtain its API token. Store that token in the n8n Pushover credential. In Push Daily Headlines, replace REPLACE_PUSHOVER_USER_KEY with your own user key and select the credential. Install/configure the receiving Pushover app.

<b>6.</b> Open workflow settings and select your timezone. The supplied default is <b>Asia/Karachi</b>. Every Day 8 AM runs at 08:00 in that timezone; Run Now ignores the schedule.

Setup value | Default / purpose

lookbackDays | 2; accept recent stories within this window

maxArticles | 40; maximum AI evaluations per run

minScore | 60; minimum notification score

maxHeadlines | 8; maximum displayed headlines

Edit the four topics and search queries in Build Feed List to change subjects. Keep numeric settings positive; use a score between 0 and 100. AI evaluates headlines/snippets, not full articles. Notification links open the sheet containing original article URLs.

# Test before activating

<b>1. Small trial:</b> set maxArticles to 4. Execute the entire workflow from Run Now. A real test calls the model, writes rows and may send a notification.

<b>2. Inspect feeds:</b> confirm Read News Feeds has results from the configured feeds and Tag Topic contains the expected topic names. Feed availability and article counts vary.

<b>3. Inspect ratings:</b> check that each summary matches its source title. Scores must be numbers from 0 to 100; malformed model output stops the run instead of silently saving a zero score.

<b>4. Inspect the sheet:</b> check all ten columns, clickable URLs, and one row per article_id. Confirm that Pushover opens the sheet and that the headline count matches the message.

<b>5. Verify repeats:</b> run again. Previously committed URLs should be skipped; new unseen URLs may still be processed. With no new eligible articles, the workflow ends without a notification. With articles but no score above the threshold, it saves and commits them without sending a push.

<b>6. Failure test:</b> in a duplicate test workflow with a fresh test table, use an invalid Pushover user key and a low score threshold. Confirm the run fails after sheet writing and Save Article does not run. Restore the correct key and retry; existing sheet rows should update.

## Recovery and limits

Errors stop execution. Fix the failed node and retry promptly. Completion records are written only after required outputs succeed. If the push succeeds but the final table write fails, a retry can repeat the notification. There is no transactional, exactly-once delivery across services.

A new full run re-fetches RSS feeds; it is not a durable pending queue. Stories that leave the feed or fall outside lookbackDays may not be recovered. Preserve failed execution data and use n8n execution retry where supported. Run one execution at a time to avoid concurrent duplicates. For unattended production, add a persistent outbox and separate delivery worker.

After testing, restore maxArticles to your desired budget, save, then activate/publish the workflow using your n8n version's controls. Remove pinned test data.

# Choose a different setup

Option | What to change | Tradeoff

Telegram instead of Pushover | Replace Push Daily Headlines with Telegram Send Message. | Bot setup; uses a chat rather than a push-only app.

Email instead of Pushover | Replace push node with Send Email using SMTP credentials. | Email delivery depends on provider settings.

Another hosted AI model | Replace News Model with a supported Chat Model node. | Model costs and JSON reliability vary.

Local Ollama model | Connect Ollama Chat Model to Rate Article. | Requires reachable local hosting and a capable model.

## Telegram: practical alternative

Create a bot through Telegram BotFather, store its token in n8n Telegram credentials, and start a chat with your bot. Obtain your own chat ID using a Telegram Trigger test message. Replace the Pushover node with Telegram: Message / Send Message. Map text to <b>{{ $json.message + "\n\n" + $json.digestUrl }}</b> and use plain text (disable Markdown/HTML parsing). Connect Has Headlines true output to Telegram, and Telegram success to Articles to Commit. Keep the false output connected directly to Articles to Commit. Delete the disconnected Pushover node.

## Email: same flow, different delivery

Connect a Send Email node to Has Headlines true output. Configure your SMTP credential and sender/recipient. Use subject Daily News Digest and plain-text body <b>{{ $json.message + "\n\n" + $json.digestUrl }}</b>. Connect success to Articles to Commit. Use one notification channel unless you intentionally want several.

## AI providers and local inference

Remove News Model and add your provider's Chat Model node; connect its model output to Rate Article. Keep the structured parser and prompt. Test with four articles and a low temperature. For Ollama, install/download a suitable model, configure its base URL reachable from n8n, and select the exact installed model name. A cloud n8n instance cannot reach your PC's localhost; use an authenticated, secure connection or run n8n alongside Ollama. Local inference does not remove the need for internet RSS and cloud outputs.

Alternatives are instructions, not additional prebuilt or live-tested workflows. Provider-specific settings must be verified in your environment.

# Troubleshooting and release notes

Symptom | Check / action

Unknown node or version | Update n8n or recreate that node with the equivalent available version. No minimum version is claimed as tested.

Setup error | Replace resource placeholders; verify both data-table nodes target the same table.

Model / parser error | Select an available model, check billing/access, and use a model that follows the JSON schema.

Missing sheet fields | Check the News tab, headers, Google permission and article_id match column.

No notification | No new stories, no qualifying scores, wrong receiving account, or a failed node. Inspect execution output.

Wrong daily time | Check workflow timezone and activation state.

Table grows large | Get Seen Articles reads the full table. Introduce retention appropriate to your lookback window; avoid deleting rows during active runs.

## Changes from the original

Removed personal credentials and resource IDs; replaced the tool-less Agent with a Basic LLM Chain; added strict rating validation; balanced topic selection; preserved full URLs; rejected stale/undated items; stopped silent failures; changed sheet writes to upserts; moved seen tracking after delivery; built complete bounded headlines with an accurate count; added a sheet link and explicit timezone.

## Before uploading to GitHub

Upload this sanitized JSON, the guide and README. Never publish a configured export containing tokens, user keys, account references or private document IDs. Keep credentials in n8n. The ZIP includes offline tests, but those do not prove live execution. Add your chosen license before inviting redistribution; this package does not choose legal terms for you.

## Official references / checked 4 October 2026
